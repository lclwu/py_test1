## 迁移python3

1. `PyMySQL` 用 `mysqlclient`
2. `decode` 变 `encode`



## 生成requirements.txt文件
```
pip freeze > requirements.txt

```

## 安装requirements.txt依赖
```
pip install -r requirements.txt
```
