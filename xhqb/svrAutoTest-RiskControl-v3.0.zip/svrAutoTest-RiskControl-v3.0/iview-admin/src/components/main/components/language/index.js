import Language from './language.vue'
export default Language
