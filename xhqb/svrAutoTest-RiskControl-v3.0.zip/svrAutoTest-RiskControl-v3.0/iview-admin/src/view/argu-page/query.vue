<template>
  <div>
    <Card>
      <h2>ID: {{ $route.query.id }}</h2>
    </Card>
  </div>
</template>

<script>
export default {
  name: 'query'
}
</script>

<style>

</style>
